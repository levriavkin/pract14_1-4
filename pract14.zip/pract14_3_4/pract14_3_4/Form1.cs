﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pract14_3_4
{
    public partial class Form1 : Form
    {
        string filename = "people.txt";
        private Queue<int> queue;
        public Form1()
        {
            InitializeComponent();
            queue = new Queue<int>();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = (int)numericUpDown1.Value; 
            for (int i = 1; i <= n; i++)
            {
                queue.Enqueue(i);
            }

            MessageBox.Show("Очередь заполнена!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (queue.Count == 0) 
            {
                MessageBox.Show("Очередь пуста!");
                return;
            }

            int number = queue.Dequeue(); 
            MessageBox.Show("Из очереди извлечено число: " + number);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(filename);

            
            foreach (string line in lines)
            {
                string[] parts = line.Split(' ');

                double age = int.Parse(parts[3]);

                if (age < 40)
                {
                    listBox1.Items.Add(line);
                }
                else
                {
                    listBox2.Items.Add(line);
                }
            }
        }
    }
}
